export class CreateBook {
    readonly name: string;
    readonly value: number;
    readonly pageQuantity: number;
}